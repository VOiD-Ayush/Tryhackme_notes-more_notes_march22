public final class c {
   public static int c = -1;
   public static int 0 = -1;
   public static int 1 = 1;
   public static int 2 = 1;
   public static int 3 = 0;
}
